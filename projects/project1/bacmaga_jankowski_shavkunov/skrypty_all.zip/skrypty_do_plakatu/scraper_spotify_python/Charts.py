import time
from seleniumwire import webdriver
from selenium.webdriver.common.by import By
from seleniumwire.utils import decode
from selenium.webdriver import FirefoxOptions
import json
import httpx
import configparser
import numpy as np
import csv
import pandas as pd
from datetime import timedelta,date

parser = configparser.ConfigParser()
parser.read("config.ini")

email = parser["SPOTIFY"]["email"]
password = parser["SPOTIFY"]["password"]


def check_token():
    url = "https://api.spotify.com/v1/me"
    token = open("token.txt", 'r').read()
    headers = {
        "authorization": f"Bearer {token}",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0",
    }
    http_s = httpx.Client()
    response = http_s.get(url, headers=headers)
    if response.status_code == 200:
        return True
    else:
        return False


def charts_token():
    fireFoxOptions = FirefoxOptions()
    fireFoxOptions.headless = False
    fireFoxOptions.executable_path = r"C:\Users\rober\Downloads\geckodriver-v0.33.0-win32\geckodriver.exe"
    fireFoxOptions.binary = r"C:\Users\rober\Downloads\FirefoxPortable\App\Firefox\firefox.exe"
    
    driver = webdriver.Firefox(options=fireFoxOptions)

    driver.get(
        "https://accounts.spotify.com/en/login?continue=https%3A%2F%2Fcharts.spotify.com/login"
    )
    driver.find_element(By.ID, "login-username").send_keys(email)
    driver.find_element(By.ID, "login-password").send_keys(password)
    driver.find_element(By.ID, "login-button").click()
    time.sleep(10)
    for request in driver.requests:
        if request.url.startswith("https://accounts.spotify.com/api/token"):
            data = decode(
                request.response.body,
                request.response.headers.get("Content-Encoding", "identity"),
            ).decode("utf8")
            data = json.loads(data)
            driver.quit()
            open("token.txt", 'w').write(data["access_token"])
            return data["access_token"]


def list_countries() -> list:

    countries = json.load(open("countries.json", "r"))
    return countries



def weekly_top_songs(country_code: str, date_="latest") -> list:

    token = open("token.txt", 'r').read() if check_token() else charts_token()
    url = f"https://charts-spotify-com-service.spotify.com/auth/v0/charts/regional-{country_code.lower()}-weekly/{date_}"
    headers = {
        "authorization": f"Bearer {token}",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0",
    }
    http_s = httpx.Client()
    response = http_s.get(url, headers=headers)
    response = response.json()
    return response


    
def main():
    print("start")
    charts_token()
    print(check_token())
    
    
    countries = list_countries()
    for country in countries:
        try:
            d = date(2022,1,6)
            #d = date(2022,12,29)
            for i in range(1,53):
                try:
                    print("Pobieram dla "+str(d)+" kraju " + country['countryCode'])
                    lista = weekly_top_songs(country['countryCode'],d)
                    uris = []
                    for entry in lista['entries']:
                        #print(entry['trackMetadata']['trackUri'])
                        uris.append(entry['trackMetadata']['trackUri'])
                    #print(lista['entries'][0]['trackMetadata']['trackUri'])
                    
                    dictionary = {'uri': uris} 
                    df = pd.DataFrame(dictionary)     
                    df.to_csv('uris' + country['countryCode'] + str(d) + '.csv')
                except:
                    pass
                d = d + timedelta(days=7)
        except Exception as e:
            print(e)
            pass
    #with open("lista.txt", 'w', encoding="UTF-8") as f:
    #    f.write(str(uris))
    print("end")
    #weekly_top_songs("pl", "latest")
    
if __name__ == '__main__':
    main()
